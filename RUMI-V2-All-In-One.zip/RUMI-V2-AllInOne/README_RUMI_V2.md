# RUMI V2 — All-in-One Foundation

## Included
- Chat + persistent local memory
- Offline/Online mode switch
- Voice input + text-to-speech replies
- Truth Engine UI with explicit no-fabrication behavior
- Study Mode foundation
- Tools hub for future calculator, documents, images, maps, automation and Android actions
- Privacy/settings screen
- Replaceable Brain interface for local LLM and online provider

## Important
This is a modular Android foundation, not a magically bundled full AI model. A production local LLM requires a model runtime and model weights, which can be hundreds of MB or more and vary by device. Live web/AI verification requires a configured provider/backend. No private API key should be hard-coded into the APK.

Open this folder in Android Studio and Sync/Build.
