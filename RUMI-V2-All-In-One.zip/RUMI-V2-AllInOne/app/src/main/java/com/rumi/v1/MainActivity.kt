package com.rumi.v1

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

// RUMI V2: modular foundation. Real local LLMs and online providers can implement Brain.
interface Brain { fun reply(input: String, online: Boolean, context: String): BrainResult }
data class BrainResult(val text: String, val confidence: String = "local", val sources: List<String> = emptyList())

class LocalBrain : Brain {
    override fun reply(input: String, online: Boolean, context: String): BrainResult {
        val q=input.trim(); val l=q.lowercase(Locale.getDefault())
        val answer=when {
            l in listOf("hi","hello","hey","hii","namaste") -> "Hello 👋 Main RUMI hoon. Main tumhare saath hoon."
            l.contains("who are you") -> "Main RUMI hoon — tumhara modular personal AI. Offline mein local brain, aur online mein connected brain use kiya ja sakta hai."
            l.startsWith("remember ") -> "Theek hai. Is message ko local memory mein save kar diya gaya hai."
            l.contains("what do you remember") -> "Meri local memory mein isi app ki saved chat aur memory notes rakhe ja sakte hain."
            l.contains("study") || l.contains("padhai") -> "Study Mode mein topic, short notes, questions aur revision plan bana sakte ho."
            l.contains("time") -> "Local time: ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())}."
            l.contains("truth") || l.contains("verify") -> "Truth Engine kisi claim ko evidence ke saath verify karne ke liye designed hai. Offline mode mein main verification ko confirmed nahi bataunga jab evidence available na ho."
            else -> if (online) "Online mode selected hai. Live provider connect hone par current web/AI research yahan aayegi. Abhi main local fallback se jawab de raha hoon." else "Offline mode active hai. Main local fallback brain se jawab de raha hoon; current internet facts ke liye online verification zaroori hai."
        }
        return BrainResult(answer, if (online) "local-fallback" else "offline-local")
    }
}

data class ChatMessage(val role:String,val text:String,val time:Long=System.currentTimeMillis())

class MemoryStore(context:Context){
    private val p=context.getSharedPreferences("rumi_memory",Context.MODE_PRIVATE)
    fun load():MutableList<ChatMessage>{
        val raw=p.getString("messages",null)?:return mutableListOf(ChatMessage("RUMI","RUMI V2 ready. Main offline-first hoon."))
        return try{val a=JSONArray(raw);MutableList(a.length()){i->val o=a.getJSONObject(i);ChatMessage(o.getString("role"),o.getString("text"),o.optLong("time"))}}catch(_:Exception){mutableListOf()}
    }
    fun save(ms:List<ChatMessage>){val a=JSONArray();ms.takeLast(300).forEach{m->a.put(JSONObject().apply{put("role",m.role);put("text",m.text);put("time",m.time)})};p.edit().putString("messages",a.toString()).apply()}
    fun addNote(note:String){val old=p.getStringSet("notes",emptySet())!!.toMutableSet();old.add(note);p.edit().putStringSet("notes",old).apply()}
    fun notes():List<String>=p.getStringSet("notes",emptySet())!!.toList().sorted()
    fun clear(){p.edit().clear().apply()}
}

enum class Screen { CHAT, STUDY, TRUTH, MEMORY, TOOLS, SETTINGS }

class MainActivity:ComponentActivity(){
    private lateinit var tts:TextToSpeech
    private val micPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){if(it)startVoice()}
    private val speech=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){r->if(r.resultCode==RESULT_OK){r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let{voiceCallback?.invoke(it)}}}
    private var voiceCallback:((String)->Unit)?=null
    override fun onCreate(b:Bundle?){super.onCreate(b);val mem=MemoryStore(this);val brain:Brain=LocalBrain();tts=TextToSpeech(this){if(it==TextToSpeech.SUCCESS)tts.language=Locale.getDefault()};setContent{RumiApp(mem,brain,{s->tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"rumi")},{cb->voiceCallback=cb;if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)startVoice()else micPermission.launch(Manifest.permission.RECORD_AUDIO)})}}
    private fun startVoice(){speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault());putExtra(RecognizerIntent.EXTRA_PROMPT,"RUMI ko bolo…")})}
    override fun onDestroy(){if(::tts.isInitialized)tts.shutdown();super.onDestroy()}
}

@Composable fun RumiApp(memory:MemoryStore,brain:Brain,speak:(String)->Unit,mic:( ((String)->Unit)->Unit)){
    var screen by remember{mutableStateOf(Screen.CHAT)};var online by remember{mutableStateOf(false)};var input by remember{mutableStateOf("")};var voiceOn by remember{mutableStateOf(true)}
    val msgs=remember{mutableStateListOf<ChatMessage>().apply{addAll(memory.load())}};var studyTopic by remember{mutableStateOf("")};var claim by remember{mutableStateOf("")};var truthResult by remember{mutableStateOf("")};var note by remember{mutableStateOf("")}
    MaterialTheme{Scaffold(bottomBar={NavigationBar{Screen.values().forEach{s->NavigationBarItem(selected=screen==s,onClick={screen=s},icon={Text(icon(s))},label={Text(label(s))})}}}){pad->Column(Modifier.fillMaxSize().padding(pad)){
        TopAppBar(title={Column{Text("RUMI");Text(if(online)"ONLINE • verification-ready" else "OFFLINE • local-first",style=MaterialTheme.typography.labelSmall)}},actions={TextButton(onClick={online=!online}){Text(if(online)"Online" else "Offline")}})
        when(screen){
            Screen.CHAT->ChatScreen(msgs,input,{input=it},{q->if(q.isNotBlank()){msgs.add(ChatMessage("YOU",q));if(q.lowercase().startsWith("remember "))memory.addNote(q.removePrefix("remember ").trim());val r=brain.reply(q,online,msgs.takeLast(8).joinToString{it.text});msgs.add(ChatMessage("RUMI",r.text));memory.save(msgs);if(voiceOn)speak(r.text);input=""}},{cb->mic{cb(it)}},{voiceOn={voiceOn=!voiceOn}})
            Screen.STUDY->StudyScreen(studyTopic,{studyTopic=it},{topic->msgs.add(ChatMessage("RUMI","Study plan for $topic:\n1. Concept samjho\n2. Short notes banao\n3. 10 questions solve karo\n4. Galtiyon ko revise karo\n5. Test do"));memory.save(msgs);screen=Screen.CHAT})
            Screen.TRUTH->TruthScreen(claim,{claim=it},truthResult,{truthResult=verifyClaim(it,online)})
            Screen.MEMORY->MemoryScreen(memory,msgs,{memory.clear();msgs.clear();msgs.add(ChatMessage("RUMI","Local memory cleared."));memory.save(msgs)})
            Screen.TOOLS->ToolsScreen()
            Screen.SETTINGS->SettingsScreen(online,{online=!online},voiceOn,{voiceOn=!voiceOn})
        }
    }}}
}

@Composable fun ChatScreen(ms:List<ChatMessage>,input:String,setInput:(String)->Unit,send:(String)->Unit,mic:( ((String)->Unit)->Unit),voiceOn:()->Unit){Column(Modifier.fillMaxSize().padding(12.dp)){LazyColumn(Modifier.weight(1f).fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(8.dp)){items(ms){m->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(m.role,style=MaterialTheme.typography.labelLarge);Text(m.text)}}}};Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(input,setInput,Modifier.weight(1f),placeholder={Text("RUMI se pucho…")});Spacer(Modifier.width(5.dp));Button(onClick={mic{setInput(it)}}){Text("🎙")};Spacer(Modifier.width(5.dp));Button(onClick={send(input)}){Text("Send")}};TextButton(onClick=voiceOn){Text("🔊 Voice")}}}

@Composable fun StudyScreen(topic:String,set:(String)->Unit,go:(String)->Unit){Column(Modifier.padding(16.dp)){Text("📚 Study Mode",style=MaterialTheme.typography.headlineSmall);Text("Topic do, RUMI study plan banayega.");Spacer(Modifier.height(12.dp));OutlinedTextField(topic,set,Modifier.fillMaxWidth(),label={Text("Topic / Chapter")});Spacer(Modifier.height(8.dp));Button(onClick={go(topic)},enabled=topic.isNotBlank()){Text("Create Study Plan")}}}

@Composable fun TruthScreen(claim:String,set:(String)->Unit,result:String,verify:()->Unit){Column(Modifier.padding(16.dp)){Text("🔎 Truth Engine",style=MaterialTheme.typography.headlineSmall);Text("Claim ko evidence ke bina confirmed fact mat samjho.");Spacer(Modifier.height(12.dp));OutlinedTextField(claim,set,Modifier.fillMaxWidth(),label={Text("Claim")});Spacer(Modifier.height(8.dp));Button(onClick=verify,enabled=claim.isNotBlank()){Text("Analyze")};if(result.isNotBlank()){Spacer(Modifier.height(12.dp));Card{Text(result,Modifier.padding(12.dp))}}}}

@Composable fun MemoryScreen(memory:MemoryStore,ms:List<ChatMessage>,clear:()->Unit){Column(Modifier.padding(16.dp)){Text("💾 Memory",style=MaterialTheme.typography.headlineSmall);Text("Chat history aur explicit memory notes device par stored hain.");Spacer(Modifier.height(10.dp));Text("Notes",style=MaterialTheme.typography.titleMedium);memory.notes().forEach{Text("• $it")};Spacer(Modifier.height(10.dp));Text("Saved messages: ${ms.size}");Spacer(Modifier.height(10.dp));OutlinedButton(onClick=clear){Text("Clear Local Memory")}}}

@Composable fun ToolsScreen(){Column(Modifier.padding(16.dp)){Text("🛠 Tools",style=MaterialTheme.typography.headlineSmall);Text("Current foundation:");listOf("Calculator / reasoning layer","Document & PDF module hook","Image understanding/generation hook","Android actions with confirmation","Offline maps & downloaded data hook","Automation/reminders hook","Online research connector hook").forEach{Text("• $it",Modifier.padding(vertical=4.dp))};Spacer(Modifier.height(12.dp));Text("Safety: risky actions should require confirmation.")}}

@Composable fun SettingsScreen(online:Boolean,toggleOnline:()->Unit,voice:Boolean,toggleVoice:()->Unit){Column(Modifier.padding(16.dp)){Text("⚙ Settings",style=MaterialTheme.typography.headlineSmall);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Online mode");Switch(online,{toggleOnline()})};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Voice replies");Switch(voice,{toggleVoice()})};Spacer(Modifier.height(12.dp));Text("Privacy",style=MaterialTheme.typography.titleMedium);Text("RUMI V2 local memory is stored inside the app. Do not bundle private API keys inside the APK.");Text("For real online AI, use a secure backend or user-provided provider configuration.")}}

fun verifyClaim(c:String,online:Boolean):String=if(!online)"Status: NOT VERIFIED\nOffline mode mein live sources available nahi hain. Is claim ko confirmed fact na samjho.\nNext: Online mode + trusted sources se cross-check." else "Status: VERIFICATION PIPELINE READY\nClaim: $c\nLive source connector abhi configured nahi hai, isliye main evidence fabricate nahi karunga."
fun icon(s:Screen)=when(s){Screen.CHAT->"💬";Screen.STUDY->"📚";Screen.TRUTH->"🔎";Screen.MEMORY->"💾";Screen.TOOLS->"🛠";Screen.SETTINGS->"⚙"}
fun label(s:Screen)=when(s){Screen.CHAT->"Chat";Screen.STUDY->"Study";Screen.TRUTH->"Truth";Screen.MEMORY->"Memory";Screen.TOOLS->"Tools";Screen.SETTINGS->"Settings"}
